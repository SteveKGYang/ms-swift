# 4 * 65GiB
# Due to the use of group_by_length, the data is not sufficiently shuffled,
# which may cause fluctuations in the loss curve. Please adjust the parameters accordingly.
PYTORCH_CUDA_ALLOC_CONF='expandable_segments:True' \
NPROC_PER_NODE=4 \
CUDA_VISIBLE_DEVICES=0,1,2,3 \
megatron sft \
    --model google/gemma-4-12B-it \
    --save_safetensors true \
    --dataset 'AI-ModelScope/LaTeX_OCR:human_handwrite#2000' \
    --load_from_cache_file true \
    --add_non_thinking_prefix true \
    --loss_scale ignore_empty_think \
    --split_dataset_ratio 0.01 \
    --tuner_type full \
    --tensor_model_parallel_size 4 \
    --micro_batch_size 16 \
    --global_batch_size 16 \
    --recompute_granularity full \
    --recompute_method uniform \
    --recompute_num_layers 1 \
    --num_train_epochs 1 \
    --finetune true \
    --freeze_llm false \
    --freeze_vit true \
    --freeze_aligner true \
    --cross_entropy_loss_fusion true \
    --lr 1e-5 \
    --lr_warmup_fraction 0.05 \
    --min_lr 1e-6 \
    --output_dir megatron_output/gemma-4-12B-it \
    --eval_steps 500 \
    --save_steps 500 \
    --max_length 4096 \
    --dataloader_num_workers 8 \
    --dataset_num_proc 8 \
    --no_save_optim true \
    --no_save_rng true \
    --sequence_parallel true \
    --attention_backend unfused \
    --group_by_length true \
    --padding_free false

# CUDA_VISIBLE_DEVICES=0 swift infer \
#     --model megatron_output/gemma-4-12B-it/vx-xxx/checkpoint-xxx \
#     --stream true \
#     --enable_thinking false \
#     --load_data_args true \
#     --max_new_tokens 2048
